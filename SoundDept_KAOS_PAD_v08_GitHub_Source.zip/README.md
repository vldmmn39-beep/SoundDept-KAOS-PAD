# Sound Dept KAOS PAD v0.8 — Side Synth

Android Studio project for Redmi Pad SE. The landscape tablet layout keeps the neon XY performance pad on the left and the full synth editor with horizontal sliders permanently on the right. Classic edit mode remains available; portrait stacks the editor below the pad.

## Features in this build
- Web Audio synthesizer and XY performance pad.
- 18 scales and octave controls.
- User preset save/load in WebView local storage.
- 8 tempo-synchronised gesture tracks with mute/clear and loop settings.
- WAV sample loading and pitch-shift playback.
- MIDI Clock slave bridge through Android MIDI API (best-effort; physical BLE MIDI/Tascam testing still required).
- Wired audio output remains independent of MIDI transport; use the tablet's 3.5 mm jack/headphones.

## Build APK
GitHub Actions workflow: **Build KAOS PAD APK**. It builds `app-debug.apk` on push to `main` or via manual workflow dispatch and uploads the APK as an artifact.

## Important limitations
- The sound engine is the browser Web Audio prototype, not a port of Clipper/SLOOP DSP.
- MIDI clock is experimental and not verified against a physical FM-1 or Tascam Model 12.
- The Android app is a WebView wrapper. First install and test audio latency, sample import, local preset persistence, and MIDI permissions on the actual tablet.
- Debug APK is for private testing, not Play Store release.
