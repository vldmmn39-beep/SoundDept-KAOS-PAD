package com.sounddept.kaospad;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.content.Context;
import android.webkit.WebView;
import android.webkit.WebChromeClient;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.media.midi.MidiManager;
import android.media.midi.MidiDeviceInfo;
import android.media.midi.MidiDevice;
import android.media.midi.MidiOutputPort;
import android.media.midi.MidiReceiver;
import org.json.JSONArray;

public class MainActivity extends Activity {
  private WebView web;
  private MidiManager midi;
  private MidiDevice device;
  private MidiOutputPort out;
  private final Handler mainHandler = new Handler(Looper.getMainLooper());
  private boolean midiRequested = false;
  private final MidiReceiver receiver = new MidiReceiver() {
    @Override public void onSend(byte[] bytes, int offset, int count, long timestamp) {
      if (!midiRequested || web == null) return;
      JSONArray json = new JSONArray();
      for (int i = offset; i < offset + count; i++) json.put(bytes[i] & 0xFF);
      final String call = "window.nativeMidiMessage(" + json.toString() + ",performance.now());";
      mainHandler.post(() -> { if(web != null) web.evaluateJavascript(call, null); });
    }
  };
  public class MidiBridge {
    @JavascriptInterface public void connect() { mainHandler.post(() -> connectMidi()); }
    @JavascriptInterface public void disconnect() { mainHandler.post(() -> disconnectMidi()); }
  }
  @Override public void onCreate(Bundle saved) {
    super.onCreate(saved);
    midi = (MidiManager) getSystemService(Context.MIDI_SERVICE);
    web = new WebView(this);
    web.getSettings().setJavaScriptEnabled(true);
    web.getSettings().setDomStorageEnabled(true);
    web.getSettings().setAllowFileAccess(true);
    web.getSettings().setMediaPlaybackRequiresUserGesture(true);
    web.setWebChromeClient(new WebChromeClient());
    web.setWebViewClient(new WebViewClient());
    web.addJavascriptInterface(new MidiBridge(), "SoundDeptNativeMidi");
    setContentView(web);
    web.loadUrl("file:///android_asset/index.html");
  }
  private void connectMidi() {
    disconnectMidi();
    midiRequested=true;
    if(midi==null){status("Android MIDI API not found");return;}
    MidiDeviceInfo[] infos = midi.getDevices();
    MidiDeviceInfo pick = null;
    for(MidiDeviceInfo info: infos){
      if(info.getOutputPortCount() < 1) continue;
      String name = String.valueOf(info.getProperties().getString(MidiDeviceInfo.PROPERTY_NAME));
      if(pick==null || name.toLowerCase().contains("tascam") || name.toLowerCase().contains("model 12"))pick=info;
      if(name.toLowerCase().contains("tascam") || name.toLowerCase().contains("model 12"))break;
    }
    if(pick==null){status("MIDI input not found · connect USB OTG or BLE MIDI bridge");return;}
    final String name = String.valueOf(pick.getProperties().getString(MidiDeviceInfo.PROPERTY_NAME));
    midi.openDevice(pick, opened -> {
      if (!midiRequested || opened==null){if(opened!=null)opened.close();status("Cannot open MIDI device");return;}
      device=opened;
      try{
        out=opened.openOutputPort(0); // device output => application input
        if(out!=null){out.connect(receiver);status("MIDI ready: "+name+" · press PLAY on Tascam");}
        else status("No MIDI output port 0");
      }catch(Exception e){status("MIDI error: "+e.getMessage());}
    }, mainHandler);
  }
  private void status(String s){
    final String encoded = org.json.JSONObject.quote(s);
    mainHandler.post(()->{ if(web!=null)web.evaluateJavascript("document.getElementById('midiStatus').textContent="+encoded+";",null); });
  }
  private void disconnectMidi(){
    midiRequested=false;
    try{if(out!=null){out.disconnect(receiver);out.close();}}catch(Exception ignored){}
    out=null;
    try{if(device!=null)device.close();}catch(Exception ignored){}
    device=null;
  }
  @Override protected void onDestroy(){disconnectMidi();if(web!=null){web.destroy();web=null;}super.onDestroy();}
  @Override public void onBackPressed(){if(web!=null&&web.canGoBack())web.goBack();else super.onBackPressed();}
}
